﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace ConnectedDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        public MainWindow()
        {
            InitializeComponent();

            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan20_Pune;uid=sqluser;pwd=sqluser");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayData();
        }

        public void DisplayData()
        {
            cmd = new SqlCommand("SELECT * FROM Student_Master", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            //while (dr.Read())
            //{
            //    MessageBox.Show(dr["Stud_Code"] + " " + dr["Stud_Name"]);
            //}
            con.Close();

            dgStudent.ItemsSource = dt.DefaultView;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            //METHOD-1 FOR INSERT DATA 
            Student stud = new Student();
            stud.StudCode = Convert.ToInt32(txtStudCode.Text);
            stud.StudName = txtStudName.Text;
            stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
            stud.DOB = Convert.ToDateTime(txtStudDob.Text);
            stud.Address = txtAddress.Text;


            //METHOD-2 FOR INSERT DATA 
            cmd = new SqlCommand("INSERT INTO Student_Master(Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address) VALUES( @scode,@name, @dcode, @dob, @address)", con);

            
            //METHOD-2.1 
            SqlParameter scode = new SqlParameter();
            scode.ParameterName = "@scode";
            scode.SqlDbType = SqlDbType.Decimal;
            scode.Direction = ParameterDirection.Input;
            scode.Value = stud.StudCode;
            cmd.Parameters.Add(scode);

            //METHOD-2.2
            //SqlParameter sname = new SqlParameter("@name", stud.StudName);
            //cmd.Parameters.Add(sname);

            //METHOD-2.3
            cmd.Parameters.AddWithValue("@name", stud.StudName);
            cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
            cmd.Parameters.AddWithValue("@dob", stud.DOB);
            cmd.Parameters.AddWithValue("@address", stud.Address);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record added successfully");
                DisplayData();
            }
            else
                MessageBox.Show("Record not added");
        }
    }
}
