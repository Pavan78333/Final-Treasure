﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace ProductManagementApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      public static string connectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(connectionString);
        SqlCommand command = new SqlCommand();
        public MainWindow()
        {
            InitializeComponent();
        }
        //Reset the text box after adding
        private void reset()
        {
            txt_Name.Text = txt_Price.Text = txt_Quantity.Text = " ";
            txt_Id.Focus();
        }

        //inserting data to database
        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
               
                string productName = txt_Name.Text;
                float price = float.Parse(txt_Price.Text);
                int quantity = int.Parse(txt_Quantity.Text);
                //command.CommandText = ("insert into  ProductInfo_46023361 values('" + productName + "' ,'" + price + "' ,'" + quantity+ "')");
                //command.Connection = connection;
                string insertQuerry=("insert into  ProductInfo_46023361 values('" + productName + "' ,'" + price + "' ,'" + quantity+ "')");
                command = new SqlCommand(insertQuerry,connection);
                int numberOfRowsAdded = command.ExecuteNonQuery();
                if (numberOfRowsAdded != 0)
                {
                    MessageBox.Show("Product Added Successfully");
                    reset();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong!!!");
                }
            }
            catch(SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                
                command.Dispose();
                if(connection.State== ConnectionState.Open)
                connection.Close();
               
            }
            getProductCount();
            DisplayData();
           

        }
        private void Window_loaded(object sender,RoutedEventArgs e)
        {
            getProductCount();
            DisplayData();
            
        }

        private void DisplayData()
        {
            try
            {
                connection.Open();


                //command.CommandText ="select * from ProductInfo_46023361";
                //command.Connection = connection;
                string insertQuerry = "select * from ProductInfo_46023361";
                command = new SqlCommand(insertQuerry, connection);
                SqlDataReader reader = command.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                dgv_product.DataContext = table;
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {

                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void getProductCount()
        {
            try
            {
                connection.Open();


                //command.CommandText ="select * from ProductInfo_46023361";
                //command.Connection = connection;
                string insertQuerry = "select count(productId) from ProductInfo_46023361";
                command = new SqlCommand(insertQuerry, connection);
                int productCount = (int)command.ExecuteScalar();
                MessageBox.Show(productCount + " Product Found");
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {

                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();


                //command.CommandText = "select * from ProductInfo_46023361 where productId="+int.Parse(txt_Id.Text);
                //command.Connection = connection;
                string searchQuerry = "select * from ProductInfo_46023361 where productId="+int.Parse(txt_Id.Text);
                command = new SqlCommand(searchQuerry, connection);
                SqlDataReader reader = command.ExecuteReader();
                while(reader.Read())
                {
                    txt_Name.Text = reader["productName"].ToString();
                    txt_Price.Text = reader["productPrice"].ToString();
                    txt_Quantity.Text = reader["productQuantity"].ToString();
                }
               
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {

                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();


                //command.CommandText ="Delete from ProductInfo_46023361 where productId=" + int.Parse(txt_Id.Text);
                //command.Connection = connection;
                string deleteQuerry = "Delete from ProductInfo_46023361 where productId=" + int.Parse(txt_Id.Text);
                command = new SqlCommand(deleteQuerry, connection);

                /*******************************************************************/
                //MessageBoxResult result = MessageBox.Show("Select yes or No.", "Yes or No", MessageBoxButton.YesNo);

                //if (result == MessageBoxResult.Yes)
                //{
                //   int noOfRowDeleted = command.ExecuteNonQuery();
                //    MessageBox.Show(noOfRowDeleted +  "Record deleted successfully");
                //}
                //else if (result == MessageBoxResult.No)
                //{
                //    MessageBox.Show("Record not deleted");
                //}
                /***********************************************************************/
                MessageBoxResult result = MessageBox.Show("Select yes or No.", "Yes or No", MessageBoxButton.YesNo);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        int noOfRowDeleted = command.ExecuteNonQuery();
                        MessageBox.Show(noOfRowDeleted + "Record deleted successfully");
                        break;
                    case MessageBoxResult.No:
                        MessageBox.Show("Record not deleted");
                        break;
                    default:
                        MessageBox.Show("No option to Choose");
                        break;
                }

            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {

                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            DisplayData();
            reset();

        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                int id = int.Parse(txt_Id.Text);
                string productName = txt_Name.Text;
                float price = float.Parse(txt_Price.Text);
                int quantity = int.Parse(txt_Quantity.Text);
                string updateQuerry = string.Format("update   ProductInfo_46023361 set productName='{0}',productPrice={1},productQuantity={2} where productId={3}", productName, price, quantity,id);
                command = new SqlCommand(updateQuerry, connection);
                int noOfRowUpdated = command.ExecuteNonQuery();
                if (noOfRowUpdated != 0)
                {
                    MessageBox.Show("Product updated Successfully");
                }
                else
                {
                    MessageBox.Show("Something Went Wrong!!!");
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {

                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            DisplayData();
            reset();

        }
    }
}
