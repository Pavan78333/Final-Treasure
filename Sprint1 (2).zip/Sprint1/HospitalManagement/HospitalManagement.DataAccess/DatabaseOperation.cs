﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HospitalManagement.Exception;
using HospitalManagement.Entity;

namespace HospitalManagement.DataAccess
{
    public static class DatabaseOperation
    {

        //Serializing the Patient Class
        public static List<Patient> patients = new List<Patient>();
        public static void PatientListSerializer(Patient patient)
        {
            patients = PatientListDeSerializer();
            patients.Add(patient);
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\Patient.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, patients);
            stream.Close();

        }

        //DeSerializing the Patient Class
        public static List<Patient> PatientListDeSerializer()
        {

            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\Patient.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<Patient> patientList = (List<Patient>)formatter.Deserialize(stream);
            stream.Close();
            return patientList;
        }


        //Serializing the LabDetails Class
        public static List<LabDetails> labDetails = new List<LabDetails>();
        public static void LabListSerializer(LabDetails lab)
        {
            labDetails = LabListDeSerializer();
            labDetails.Add(lab);

            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\LabDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);

            formatter.Serialize(stream, labDetails);

            stream.Close();

        }

        //DeSerializing the LabDetails Class
        public static List<LabDetails> LabListDeSerializer()
        {
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\LabDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<LabDetails> labsList = (List<LabDetails>)formatter.Deserialize(stream);
            stream.Close();
            return labsList;
        }


        //Serializing the Appointment Class
        public static List<Appointment> appointmentDetails = new List<Appointment>();
        public static void AppointmentListSerializer(Appointment appointment)
        {
            appointmentDetails = AppointmentListDeSerializer();
            appointmentDetails.Add(appointment);
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\Appointment.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, appointmentDetails);
            stream.Close();

        }

        //DeSerializing the Appointment Class

        public static List<Appointment> AppointmentListDeSerializer()
        {
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\Appointment.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<Appointment> appointmentLists = (List<Appointment>)formatter.Deserialize(stream);
            stream.Close();
            return appointmentLists;
        }


        //Serializing the BillDetails Class
        public static List<BillDetails> billDetails = new List<BillDetails>();
        public static void BillDetailsListSerializer(BillDetails billData)
        {
            billDetails = BillDetailsListDeSerializer();
            billDetails.Add(billData);
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\BillDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, billDetails);
            stream.Close();

        }

        //DeSerializing the BillDetails Class

        public static List<BillDetails> BillDetailsListDeSerializer()
        {
            string path = @"C:\Users\Pavan Gandla\Desktop\Sprint1\BillDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<BillDetails> billDetailLists = (List<BillDetails>)formatter.Deserialize(stream);
            stream.Close();
            return billDetailLists;
        }
    }
}
