﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HospitalManagement.Exception;
using HospitalManagement.Entity;
using HospitalManagement.DataAccess;
using System.Text.RegularExpressions;


namespace HospitalManagement.BussinessLogic
{
    public class BussinessOperations
    {
        public bool CheckPatient(Patient patient)
        {
            bool isValid = true;
            if (patient.PatientId.Equals("0") && patient.PatientId.Length < 5)
            {
                isValid = false;
            }

            if (patient.PatientName.Length == 0)
            {
                isValid = false;
            }

            if (patient.PatientAge <= 0)
            {
                isValid = false;
            }
            if (patient.PatientWeight <= 0)
            {
                isValid = false;
            }
            if (patient.PatientGender.Equals("Male") || patient.PatientGender.Equals("Female") || patient.PatientGender.Equals("others"))
            {
                isValid = true;
            }
            if (patient.PatientPhoneNo.Length != 10)
            {
                isValid = false;
            }
            if (patient.PatientAddress.Length <= 0)
            {
                isValid = false;
            }
            if (patient.PatientDisease.Length <= 0)
            {
                isValid = false;
            }
            return isValid;
        }
        public bool AddPatient(Patient patient)
        {
            bool isAdded = true;
            if (CheckPatient(patient))
            {
                DatabaseOperation.PatientListSerializer(patient);
            }
            else
            {
                isAdded = false;
            }
            return isAdded;
        }
        public List<Patient> GetPatientsDetails()
        {
            return DatabaseOperation.PatientListDeSerializer();

        }
        //public bool CheckDoctor(Doctor doctor)
        //{
        //    bool isValid = true;
        //    if (doctor.DoctorId.Equals("0") && doctor.DoctorId.Length < 5)
        //    {
        //        isValid = false;
        //    }

        //    if (doctor.DoctorName.Length == 0)
        //    {
        //        isValid = false;
        //    }

        //    if (doctor.DoctorDepartment.Length <= 0)
        //    {
        //        isValid = false;
        //    }
        //    return isValid;
        //}
        //public bool AddDoctor(Doctor doctor)
        //{
        //    bool isAdded = true;
        //    if (CheckDoctor(doctor))
        //    {
        //        DatabaseOperation.DoctorListSerializer(doctor);
        //    }
        //    else
        //    {
        //        isAdded = false;
        //    }
        //    return isAdded;
        //}
        //public List<Doctor> GetDoctorsDetails()
        //{
        //    return DatabaseOperation.DoctorListDeSerializer();

        //}
        public bool CheckLab(LabDetails labdetail)
        {
            bool isValid = true;
            if (labdetail.LabId.Length <= 0)
            {
                isValid = false;
            }
            if (labdetail.LabNo.Length <= 0)
            {
                isValid = false;
            }
            
            if (labdetail.TestType.Length <= 0)
            {
                isValid = false;
            }

            if (labdetail.PatientType.Length <= 0)
            {
                isValid = false;
            }

            if (labdetail.Result.Length <= 0)
            {
                isValid = false;
            }

            return isValid;
        }
        public bool AddLabs(LabDetails lab)
        {
            bool isAdded = true;
            if (CheckLab(lab))
            {
                DatabaseOperation.LabListSerializer(lab);
            }
            else
            {
                isAdded = false;
            }
            return isAdded;
        }
        public List<LabDetails> GetLabDetails()
        {
            return DatabaseOperation.LabListDeSerializer();

        }
        public bool CheckAppiontment(Appointment appointment)
        {
            bool isValid = true;

            if (appointment.DoctorId.Equals("0") && appointment.DoctorId.Length < 5)
            {
                isValid = false;
            }

            if (appointment.DoctorName.Length == 0)
            {
                isValid = false;
            }
            if (appointment.AppointmentId.Length== 0)
            {
                isValid = false;
            }

            if (appointment.DoctorDepartment.Length <= 0)
            {
                isValid = false;
            }
            if (appointment.RoomNo.Length <= 0)
            {
                isValid = false;
            }

            if (appointment.AmmountPerDay <= 0)
            {
                isValid = false;
            }

            return isValid;
        }
        public bool AddAppointments(Appointment appointment)
        {
            bool isAdded = true;
            
            if (CheckAppiontment(appointment))
            {
                DatabaseOperation.AppointmentListSerializer(appointment);
            }
            else
            {
                isAdded = false;
            }
            return isAdded;
        }
        public List<Appointment> GetAppointmentDetails()
        {
            return DatabaseOperation.AppointmentListDeSerializer();

        }
        public bool CheckBillDetails(BillDetails billDetail)
        {
            bool isValid = true;
            if (billDetail.BillNo.Length == 0)
            {
                isValid = false;
            }

            if (billDetail.DoctorFees <= 0)
            {
                isValid = false;
            }

            if (billDetail.LabFees <= 0)
            {
                isValid = false;
            }
            if (billDetail.MedicineFees <= 0)
            {
                isValid = false;
            }
            if (billDetail.TotalDays <= 0)
            {
                isValid = false;
            }

            if (billDetail.RoomCharge <= 0)
            {
                isValid = false;
            }

            if (billDetail.OperationCharges <= 0)
            {
                isValid = false;
            }
            //if (billDetail.TotalAmmount <= 0)
            //{
            //    isValid = false;
            //}
            return isValid;
        }
        public bool AddBillDetails(BillDetails billDetail)
        {
            bool isAdded = true;
            if (CheckBillDetails(billDetail))
            {
                DatabaseOperation.BillDetailsListSerializer(billDetail);
            }
            else
            {
                isAdded = false;
            }
            return isAdded;
        }
        public List<BillDetails> GetBillDetails()
        {
            return DatabaseOperation.BillDetailsListDeSerializer();

        }
        public Patient SearchPatientById(string id)
        {
            List<Patient> patients = DatabaseOperation.PatientListDeSerializer();
            Patient patient = patients.Find(patientDetails => patientDetails.PatientId.Equals(id));
            return patient;

        
        }
        public Appointment SearchDoctorById(string id)
        {
            List<Appointment> appointments= DatabaseOperation.AppointmentListDeSerializer();
            Appointment appointment = appointments.Find(DoctorDetails => DoctorDetails.DoctorId.Equals(id));
            return appointment; 
        }
        public List<Patient> SearchPatientByName(string Name)
        {
            List<Patient> patients = DatabaseOperation.PatientListDeSerializer();
            List<Patient> searchedPatients = patients.FindAll(patientDetails => patientDetails.PatientName.Equals(Name));
            return searchedPatients;

        }
        public List< Patient> SearchPatientByGender(string Gender)
        {
            List<Patient> patients = DatabaseOperation.PatientListDeSerializer();
            List<Patient> Searchepatients = patients.FindAll(patientDetails => patientDetails.PatientGender.Equals(Gender));
            return Searchepatients;

        }
        public BillDetails SearchBillDetailsById(string id)
        {
           List<BillDetails> billDetails = DatabaseOperation.BillDetailsListDeSerializer();
            BillDetails billValue= billDetails.Find(billDetail => billDetail.BillNo.Equals(id));
            return billValue;

        }

       
    }
}
