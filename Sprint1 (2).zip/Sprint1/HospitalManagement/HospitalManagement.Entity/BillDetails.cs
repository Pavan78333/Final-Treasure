﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement.Entity
{
    [Serializable]
    public class BillDetails
    {
        public string BillNo { get; set; }
        public double DoctorFees { get; set; }
        public  double RoomCharge { get; set; }
        public double OperationCharges { get; set; }
        public double MedicineFees { get; set; }
        public double TotalDays { get; set; }
        public double LabFees { get; set; }
        public double TotalAmmount { get; set; }
    }
}
