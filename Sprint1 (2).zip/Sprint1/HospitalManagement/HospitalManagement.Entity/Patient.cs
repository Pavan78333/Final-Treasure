﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement.Entity
{
    [Serializable]
    public class Patient
    {

        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public int PatientAge { get; set; }
        public int PatientWeight { get; set; }
        public string PatientGender { get; set; }
        public string PatientAddress { get; set; }
        public string PatientPhoneNo { get; set; }
        public string PatientDisease { get; set; }

       
    }
}
